#include "dt.h"
#include <cmath>
#include <algorithm>
#include <iterator>
#include <numeric>
#include <string>
#include <sstream>
#include <set>
#include "utils.h"
namespace dt
{
	std::map<int, float> GetProbs(std::vector<std::vector<int>>& xs, int target)
	{
		std::map<int, float> num_of_each_val;
		for (auto& x : xs)
		{
			int val = x[target];
			auto itr = num_of_each_val.find(val);
			if (itr == num_of_each_val.end())
				num_of_each_val.insert(std::make_pair(val, 1.0));
			else
				itr->second++;
		}
		float total = xs.size();

		std::map<int, float> probs;
		std::vector<  std::pair<int, float> > probs_tmp;
		//	std::for_each(num_of_each_val.begin(), num_of_each_val.end(), [total](std::pair<const int, float>& x) { return x.second / total; });
		std::transform(num_of_each_val.begin(), num_of_each_val.end(), std::back_inserter(probs_tmp), [total](std::pair<const int, float>& x) { return std::make_pair(x.first, x.second / total); });
		for (auto& one : probs_tmp)
		{
			probs.insert(one);
		}
		return probs;
	}

	void DTTree::Build(INPUT& input)
	{
		int feat_num = input.X[0].size();
		int sample_num = input.X.size();

		//����ÿ��nodeʱ��Ҫ������Ϣ
		//1����node���������ݣ�����ѡ������feat
		//2. ��node����ʹ�õ�feat�б�, ����ѡ������feat ��ʹ�ù�������û�б�ɾ������Ȼ������ÿ���ڵ��У�������Ҫ���ֲ�����
		//3. ��node�ĸ��ڵ�
		//4. �ýڵ��Ӧfeat��val


		std::vector<Node*> open_nodes;
		Node* cur_node = create_node();
		cur_node->_parent = NULL; //a-set parent node
		cur_node->_indices.clear(); //b-set indices
		cur_node->_depth = 0;
		for (int k = 0; k < sample_num; k++)
		{
			cur_node->_indices.push_back(k); 
		}
		cur_node->_class_probs = CalcPred(input.X, cur_node->_indices); //c-set prediction
		open_nodes.push_back(cur_node);

		while (!open_nodes.empty())
		{
			cur_node = open_nodes.back();
			open_nodes.pop_back();


			if (try_stop_split(input.X, *cur_node, input.max_depth, input.min_std))
			{
				continue;
			}


			//ѡ����ʵ�feature ������children
			std::vector<float> losses_of_feat = { 1e20 };
			std::vector<int> losses_of_dtype = { 0 };
			std::vector<float> thresholds = { 0 };
			for (int feat_index = 1; feat_index < feat_num; feat_index++)
			{
				std::vector< float > rets = CalcLoss(input.X, cur_node->_indices, feat_index, input.loss_type);
				if (rets.empty()) std::cout << "ERROR: CalcLoss() return {}" << std::endl;
				float loss_val = rets[0];
				losses_of_feat.push_back(loss_val);

				if (rets.size() == 2)
				{
					losses_of_dtype.push_back(1); //����ֵ
					thresholds.push_back(rets[1]);
				}
				else
				{
					losses_of_dtype.push_back(0);//��ɢֵ
					thresholds.push_back(0);//ռλ��
				}


			}
			std::vector<int> indices;
			for (int k = 0; k < losses_of_feat.size(); k++) indices.push_back(k);

			std::sort(indices.begin(), indices.end(), [&losses_of_feat](int a, int b) { return losses_of_feat[a] < losses_of_feat[b];  });

			int feat_selected = indices[0];
			float threshold = thresholds[feat_selected];
			cur_node->_feat_index = feat_selected;
			cur_node->_feat_dtype = input.X[0][feat_selected].dtype();
			cur_node->_threshold = threshold;
			std::map<int, std::vector<int>> splits = SplitX(input.X, cur_node->_indices, feat_selected, threshold);

			for (auto& itr : splits)
			{
				int c = itr.first;
				std::vector<int>& indices = itr.second;
				Node* new_node = create_node();
				new_node->_parent = cur_node;
				new_node->_indices = indices;
				new_node->_depth = cur_node->_depth + 1;
				new_node->_class_probs = CalcPred(input.X, new_node->_indices);
				open_nodes.push_back(new_node);

				cur_node->_children.insert( //set children
					std::make_pair(c, new_node)
				);
			}
		}

		return;
	}


	std::vector<std::map<int, float>>  DTTree::Evaluate(INPUT& input)
	{
		int target_dtype = input.X[0][0].dtype(); //��0ά��Ҫ����
		//1--find root
		Node* root = NULL;
		for (auto one : _nodes)
		{
			if (one->_parent == NULL)
			{
				root = one;
				break;
			}
		}

		//2--evaluation
		std::vector<std::map<int,float>> preds;
		for (auto sample : input.X)
		{
			//traveling in tree
			Node* cur_node = root;
			while (1)
			{
				int feat_dtype = cur_node->_feat_dtype;
				int feat_index = cur_node->_feat_index;
				bool find = false;
				if (feat_dtype == 0)
				{
					int c = sample[feat_index].i();
					auto& class2child = cur_node->_children.find(c);
					if (class2child != cur_node->_children.end())
					{
						cur_node = class2child->second;
						find = true;
					}
				}
				else
				{
					float val = sample[feat_index].f();
					if (val <= cur_node->_threshold)
					{
						cur_node = cur_node->_children[0];
					}
					else
					{
						cur_node = cur_node->_children[1];
					}
					find = true;
				}

				if (find == false || cur_node->_children.empty())
				{//node��û�ж�Ӧ��val �� �Ѿ��ﵽҶ�ӽڵ�
					preds.push_back(cur_node->_class_probs);
					break;
				}
			}

		}
		return preds;
	}

	int Solve(INPUT& input, OUTPUT& output)
	{
		output.tree.Build(input);
		return 0;
	}

};