#pragma once
#include "dt.h"

std::vector<float> CalcLoss(std::vector<std::vector<dt::VALUE>>& data, std::vector<int>& indices, int feat_index, std::string loss_type);

std::map<int, std::vector<int>> SplitX(std::vector<std::vector<dt::VALUE>>& data, std::vector<int>& indices, int feat_index, float threshold);

std::map<int, float> CalcPred(std::vector<std::vector<dt::VALUE>>& data, std::vector<int>& indices);

bool try_stop_split(std::vector<std::vector<dt::VALUE>>& data, dt::Node& node, int max_depth, float min_std);
